﻿namespace _785_App03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.txtHoraPartida = new System.Windows.Forms.TextBox();
            this.txtMinutosPartida = new System.Windows.Forms.TextBox();
            this.txtHoraDuracao = new System.Windows.Forms.TextBox();
            this.txtMinutosDuracao = new System.Windows.Forms.TextBox();
            this.txtHoraChegada = new System.Windows.Forms.TextBox();
            this.txtMinutosChegada = new System.Windows.Forms.TextBox();
            this.txtMensagem = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hora";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(169, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Minutos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-21, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1420, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "_________________________________________________________________________________" +
    "_______________________________________________";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-305, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1420, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "_________________________________________________________________________________" +
    "_______________________________________________";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(-327, 347);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(1420, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "_________________________________________________________________________________" +
    "_______________________________________________";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "Partida";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(30, 234);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Hora";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(211, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Minutos";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(21, 337);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 25);
            this.label9.TabIndex = 9;
            this.label9.Text = "Chegada";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(21, 387);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 25);
            this.label10.TabIndex = 10;
            this.label10.Text = "Hora";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(200, 387);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 25);
            this.label11.TabIndex = 11;
            this.label11.Text = "Minutos";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(30, 180);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 25);
            this.label12.TabIndex = 12;
            this.label12.Text = "Duração";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(351, 381);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(109, 45);
            this.btnCalcular.TabIndex = 13;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(351, 432);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(109, 38);
            this.btnLimpar.TabIndex = 14;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // txtHoraPartida
            // 
            this.txtHoraPartida.Location = new System.Drawing.Point(35, 140);
            this.txtHoraPartida.MaxLength = 2;
            this.txtHoraPartida.Name = "txtHoraPartida";
            this.txtHoraPartida.Size = new System.Drawing.Size(53, 20);
            this.txtHoraPartida.TabIndex = 15;
            // 
            // txtMinutosPartida
            // 
            this.txtMinutosPartida.Location = new System.Drawing.Point(174, 140);
            this.txtMinutosPartida.MaxLength = 2;
            this.txtMinutosPartida.Name = "txtMinutosPartida";
            this.txtMinutosPartida.Size = new System.Drawing.Size(72, 20);
            this.txtMinutosPartida.TabIndex = 16;
            // 
            // txtHoraDuracao
            // 
            this.txtHoraDuracao.Location = new System.Drawing.Point(35, 262);
            this.txtHoraDuracao.MaxLength = 2;
            this.txtHoraDuracao.Name = "txtHoraDuracao";
            this.txtHoraDuracao.Size = new System.Drawing.Size(53, 20);
            this.txtHoraDuracao.TabIndex = 17;
            // 
            // txtMinutosDuracao
            // 
            this.txtMinutosDuracao.Location = new System.Drawing.Point(216, 267);
            this.txtMinutosDuracao.MaxLength = 2;
            this.txtMinutosDuracao.Name = "txtMinutosDuracao";
            this.txtMinutosDuracao.Size = new System.Drawing.Size(72, 20);
            this.txtMinutosDuracao.TabIndex = 18;
            // 
            // txtHoraChegada
            // 
            this.txtHoraChegada.Location = new System.Drawing.Point(26, 415);
            this.txtHoraChegada.MaxLength = 2;
            this.txtHoraChegada.Name = "txtHoraChegada";
            this.txtHoraChegada.ReadOnly = true;
            this.txtHoraChegada.Size = new System.Drawing.Size(53, 20);
            this.txtHoraChegada.TabIndex = 19;
            // 
            // txtMinutosChegada
            // 
            this.txtMinutosChegada.Location = new System.Drawing.Point(205, 415);
            this.txtMinutosChegada.MaxLength = 2;
            this.txtMinutosChegada.Name = "txtMinutosChegada";
            this.txtMinutosChegada.ReadOnly = true;
            this.txtMinutosChegada.Size = new System.Drawing.Size(83, 20);
            this.txtMinutosChegada.TabIndex = 20;
            // 
            // txtMensagem
            // 
            this.txtMensagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMensagem.Location = new System.Drawing.Point(12, 500);
            this.txtMensagem.Name = "txtMensagem";
            this.txtMensagem.ReadOnly = true;
            this.txtMensagem.Size = new System.Drawing.Size(448, 30);
            this.txtMensagem.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 570);
            this.Controls.Add(this.txtMensagem);
            this.Controls.Add(this.txtMinutosChegada);
            this.Controls.Add(this.txtHoraChegada);
            this.Controls.Add(this.txtMinutosDuracao);
            this.Controls.Add(this.txtHoraDuracao);
            this.Controls.Add(this.txtMinutosPartida);
            this.Controls.Add(this.txtHoraPartida);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Companhia Só Ida.";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.TextBox txtHoraPartida;
        private System.Windows.Forms.TextBox txtMinutosPartida;
        private System.Windows.Forms.TextBox txtHoraDuracao;
        private System.Windows.Forms.TextBox txtMinutosDuracao;
        private System.Windows.Forms.TextBox txtHoraChegada;
        private System.Windows.Forms.TextBox txtMinutosChegada;
        private System.Windows.Forms.TextBox txtMensagem;
    }
}

