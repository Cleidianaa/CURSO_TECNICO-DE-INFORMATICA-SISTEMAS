﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0785_Carros
{
    public partial class FormListaCarros : Form
    {
        public FormListaCarros()
        {
            InitializeComponent();
        }

        private void btn_Adicionar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Marca_Dados.Text))
            {
                MessageBox.Show("Marca Inválida!", "Aviso Importante");
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Modelo_Dados.Text))
            {
                MessageBox.Show("Modelo Inválido!", "Aviso Importante");
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Matricula_Dados.Text) || txt_Matricula_Dados.Text.Trim().Length != 8)
            {
                MessageBox.Show("Matricula Inválida!", "Aviso Importante");
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_KmsAtuais_Dados.Text))
            {
                MessageBox.Show("KM Atuais Inválido!", "Aviso Importante");
                return;
            }

            if (ListaDeMarca.SelectedIndex == -1)
            {
                //Adicionar Dados Ás Listas
                ListaDeMarca.Items.Add(txt_Marca_Dados.Text);
                ListaDeModelo.Items.Add(txt_Modelo_Dados.Text);
                ListaDeMatricula.Items.Add(txt_Matricula_Dados.Text);
                ListaDekm.Items.Add(txt_KmsAtuais_Dados.Text.Trim());
            }
            else
            {
                //Atualizar Dados Ás Listas
                ListaDeMarca.Items[ListaDeMarca.SelectedIndex] = txt_Marca_Dados.Text;
                ListaDeModelo.Items[ListaDeModelo.SelectedIndex] = txt_Modelo_Dados.Text;
                ListaDeMatricula.Items[ListaDeMatricula.SelectedIndex] = txt_Matricula_Dados.Text;
                ListaDekm.Items[ListaDekm.SelectedIndex] = txt_KmsAtuais_Dados.Text.Trim();
            }

            txt_Marca_Dados.Clear();
            txt_Modelo_Dados.Clear();
            txt_Matricula_Dados.Clear();
            txt_KmsAtuais_Dados.Clear();

            ListaDekm.Enabled = true;
            ListaDeMarca.Enabled = true;
            ListaDeModelo.Enabled = true;
            ListaDeMatricula.Enabled = true;
            btn_Adicionar_Dados.Text = "Adicionar";
        }

        private void list_marca_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Sincronizar
            ListaDekm.SelectedIndex = ListaDeMarca.SelectedIndex;
            ListaDeModelo.SelectedIndex = ListaDeMarca.SelectedIndex;
            ListaDeMatricula.SelectedIndex = ListaDeMarca.SelectedIndex;
        }

        private void list_modelo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Sincronizar
            ListaDekm.SelectedIndex = ListaDeModelo.SelectedIndex;
            ListaDeMarca.SelectedIndex = ListaDeModelo.SelectedIndex;
            ListaDeMatricula.SelectedIndex = ListaDeModelo.SelectedIndex;
        }

        private void list_matricula_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Sincronizar
            ListaDekm.SelectedIndex = ListaDeMatricula.SelectedIndex;
            ListaDeModelo.SelectedIndex = ListaDeMatricula.SelectedIndex;
            ListaDeMarca.SelectedIndex = ListaDeMatricula.SelectedIndex;
        }

        private void list_km_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Sincronizar
            ListaDeMarca.SelectedIndex = ListaDekm.SelectedIndex;
            ListaDeModelo.SelectedIndex = ListaDekm.SelectedIndex;
            ListaDeMatricula.SelectedIndex = ListaDekm.SelectedIndex;
        }

        private void btn_Limpar_Click(object sender, EventArgs e)
        {
            txt_Marca_Dados.Clear();
            txt_Modelo_Dados.Clear();
            txt_Matricula_Dados.Clear();
            txt_KmsAtuais_Dados.Clear();
        }

        private void btn_Eliminar_Click(object sender, EventArgs e)
        {
            //Eliminar viatura
            if (ListaDeMarca.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um Modelo", "Aviso Importante");
                return;
            }

            //Remover
            int index = ListaDekm.SelectedIndex;
            ListaDekm.Items.RemoveAt(index);
            ListaDeMatricula.Items.RemoveAt(index);
            ListaDeModelo.Items.RemoveAt(index);
            ListaDeMarca.Items.RemoveAt(index);
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            //Alterar viatura
            if (ListaDeMarca.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um Modelo", "Aviso Importante");
                return;
            }

            txt_Marca_Dados.Text = ListaDeMarca.SelectedItem.ToString();
            txt_Modelo_Dados.Text = ListaDeModelo.SelectedItem.ToString();
            txt_Matricula_Dados.Text = ListaDeMatricula.SelectedItem.ToString();
            txt_KmsAtuais_Dados.Text = ListaDekm.SelectedItem.ToString();

            btn_Adicionar_Dados.Text = "Atualizar";
            ListaDekm.Enabled = false;
            ListaDeMarca.Enabled = false;
            ListaDeModelo.Enabled = false;
            ListaDeMatricula.Enabled = false;
        }

        private void btn_Imprimir_Click(object sender, EventArgs e)
        {
            printPreviewDialogLista.ShowDialog();
        }

        private void printDocumentLista_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("Stand Aguiar, Lda.", new Font("Verdana", 15), new SolidBrush(Color.Black), 50, 100);
            e.Graphics.DrawString("Listagem de Carros", new Font("Verdana", 15), new SolidBrush(Color.Black), 50, 150);
            e.Graphics.DrawString("Marca", new Font("Verdana", 15), new SolidBrush(Color.Black), 50, 200);
            e.Graphics.DrawString("Modelo", new Font("Verdana", 15), new SolidBrush(Color.Black), 250, 200);
            e.Graphics.DrawString("Matrícula", new Font("Verdana", 15), new SolidBrush(Color.Black), 450, 200);
            e.Graphics.DrawString("Kms Atuais", new Font("Verdana", 15), new SolidBrush(Color.Black), 650, 200);
            e.Graphics.DrawString("__________________________________________________________", new Font("Verdana", 15), new SolidBrush(Color.Black), 50, 210);
            int posicao = 250;
            for (int i = 0; i < ListaDekm.Items.Count; i++)
            {
                e.Graphics.DrawString(ListaDeMarca.Items[i].ToString(), new Font("Verdana", 15), new SolidBrush(Color.Black), 50, posicao);
                e.Graphics.DrawString(ListaDeModelo.Items[i].ToString(), new Font("Verdana", 15), new SolidBrush(Color.Black), 250, posicao);
                e.Graphics.DrawString(ListaDeMatricula.Items[i].ToString(), new Font("Verdana", 15), new SolidBrush(Color.Black), 450, posicao);
                e.Graphics.DrawString(ListaDekm.Items[i].ToString(), new Font("Verdana", 15), new SolidBrush(Color.Black), 650, posicao);

                posicao += 50;
            }
            e.Graphics.DrawString("__________________________________________________________", new Font("Verdana", 15), new SolidBrush(Color.Black), 50, 950);
            e.Graphics.DrawString("Fim da listagem.", new Font("Verdana", 15), new SolidBrush(Color.Black), 50, 1000);
        }
    }
}
