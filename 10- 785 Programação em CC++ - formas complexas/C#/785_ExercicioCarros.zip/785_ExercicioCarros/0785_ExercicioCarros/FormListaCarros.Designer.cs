﻿
namespace _0785_Carros
{
    partial class FormListaCarros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormListaCarros));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Adicionar_Dados = new System.Windows.Forms.Button();
            this.btn_Limpar_Dados = new System.Windows.Forms.Button();
            this.txt_KmsAtuais_Dados = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Matricula_Dados = new System.Windows.Forms.MaskedTextBox();
            this.txt_Modelo_Dados = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Marca_Dados = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ListaDekm = new System.Windows.Forms.ListBox();
            this.ListaDeMatricula = new System.Windows.Forms.ListBox();
            this.ListaDeModelo = new System.Windows.Forms.ListBox();
            this.ListaDeMarca = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_Imprimir = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.btn_Eliminar = new System.Windows.Forms.Button();
            this.btn_Sair = new System.Windows.Forms.Button();
            this.printPreviewDialogLista = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocumentLista = new System.Drawing.Printing.PrintDocument();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_Adicionar_Dados);
            this.groupBox1.Controls.Add(this.btn_Limpar_Dados);
            this.groupBox1.Controls.Add(this.txt_KmsAtuais_Dados);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_Matricula_Dados);
            this.groupBox1.Controls.Add(this.txt_Modelo_Dados);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txt_Marca_Dados);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(11, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(246, 434);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados";
            // 
            // btn_Adicionar_Dados
            // 
            this.btn_Adicionar_Dados.Location = new System.Drawing.Point(24, 317);
            this.btn_Adicionar_Dados.Name = "btn_Adicionar_Dados";
            this.btn_Adicionar_Dados.Size = new System.Drawing.Size(182, 46);
            this.btn_Adicionar_Dados.TabIndex = 9;
            this.btn_Adicionar_Dados.Text = "Adicionar";
            this.btn_Adicionar_Dados.UseVisualStyleBackColor = true;
            this.btn_Adicionar_Dados.Click += new System.EventHandler(this.btn_Adicionar_Click);
            // 
            // btn_Limpar_Dados
            // 
            this.btn_Limpar_Dados.Location = new System.Drawing.Point(24, 378);
            this.btn_Limpar_Dados.Name = "btn_Limpar_Dados";
            this.btn_Limpar_Dados.Size = new System.Drawing.Size(182, 50);
            this.btn_Limpar_Dados.TabIndex = 8;
            this.btn_Limpar_Dados.Text = "Limpar";
            this.btn_Limpar_Dados.UseVisualStyleBackColor = true;
            this.btn_Limpar_Dados.Click += new System.EventHandler(this.btn_Limpar_Click);
            // 
            // txt_KmsAtuais_Dados
            // 
            this.txt_KmsAtuais_Dados.Location = new System.Drawing.Point(10, 260);
            this.txt_KmsAtuais_Dados.Mask = "000000000";
            this.txt_KmsAtuais_Dados.Name = "txt_KmsAtuais_Dados";
            this.txt_KmsAtuais_Dados.Size = new System.Drawing.Size(84, 20);
            this.txt_KmsAtuais_Dados.TabIndex = 7;
            this.txt_KmsAtuais_Dados.ValidatingType = typeof(int);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Kms Atuais";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Matricula";
            // 
            // txt_Matricula_Dados
            // 
            this.txt_Matricula_Dados.Location = new System.Drawing.Point(8, 179);
            this.txt_Matricula_Dados.Mask = "AA-AA-AA";
            this.txt_Matricula_Dados.Name = "txt_Matricula_Dados";
            this.txt_Matricula_Dados.Size = new System.Drawing.Size(95, 20);
            this.txt_Matricula_Dados.TabIndex = 4;
            // 
            // txt_Modelo_Dados
            // 
            this.txt_Modelo_Dados.Location = new System.Drawing.Point(8, 99);
            this.txt_Modelo_Dados.Name = "txt_Modelo_Dados";
            this.txt_Modelo_Dados.Size = new System.Drawing.Size(206, 20);
            this.txt_Modelo_Dados.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Modelo";
            // 
            // txt_Marca_Dados
            // 
            this.txt_Marca_Dados.Location = new System.Drawing.Point(8, 42);
            this.txt_Marca_Dados.Name = "txt_Marca_Dados";
            this.txt_Marca_Dados.Size = new System.Drawing.Size(198, 20);
            this.txt_Marca_Dados.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Marca";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ListaDekm);
            this.groupBox2.Controls.Add(this.ListaDeMatricula);
            this.groupBox2.Controls.Add(this.ListaDeModelo);
            this.groupBox2.Controls.Add(this.ListaDeMarca);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(277, 49);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(832, 428);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Listas";
            // 
            // ListaDekm
            // 
            this.ListaDekm.FormattingEnabled = true;
            this.ListaDekm.Location = new System.Drawing.Point(604, 42);
            this.ListaDekm.Name = "ListaDekm";
            this.ListaDekm.Size = new System.Drawing.Size(200, 381);
            this.ListaDekm.TabIndex = 14;
            this.ListaDekm.SelectedIndexChanged += new System.EventHandler(this.list_km_SelectedIndexChanged);
            // 
            // ListaDeMatricula
            // 
            this.ListaDeMatricula.FormattingEnabled = true;
            this.ListaDeMatricula.Location = new System.Drawing.Point(415, 42);
            this.ListaDeMatricula.Name = "ListaDeMatricula";
            this.ListaDeMatricula.Size = new System.Drawing.Size(183, 381);
            this.ListaDeMatricula.TabIndex = 13;
            this.ListaDeMatricula.SelectedIndexChanged += new System.EventHandler(this.list_matricula_SelectedIndexChanged);
            // 
            // ListaDeModelo
            // 
            this.ListaDeModelo.FormattingEnabled = true;
            this.ListaDeModelo.Location = new System.Drawing.Point(226, 42);
            this.ListaDeModelo.Name = "ListaDeModelo";
            this.ListaDeModelo.Size = new System.Drawing.Size(185, 381);
            this.ListaDeModelo.TabIndex = 12;
            this.ListaDeModelo.SelectedIndexChanged += new System.EventHandler(this.list_modelo_SelectedIndexChanged);
            // 
            // ListaDeMarca
            // 
            this.ListaDeMarca.FormattingEnabled = true;
            this.ListaDeMarca.Location = new System.Drawing.Point(37, 42);
            this.ListaDeMarca.Name = "ListaDeMarca";
            this.ListaDeMarca.Size = new System.Drawing.Size(183, 381);
            this.ListaDeMarca.TabIndex = 11;
            this.ListaDeMarca.SelectedIndexChanged += new System.EventHandler(this.list_marca_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(601, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Kms Atuais";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(412, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Matricula";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(223, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Modelo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Marca";
            // 
            // btn_Imprimir
            // 
            this.btn_Imprimir.Location = new System.Drawing.Point(342, 489);
            this.btn_Imprimir.Name = "btn_Imprimir";
            this.btn_Imprimir.Size = new System.Drawing.Size(122, 48);
            this.btn_Imprimir.TabIndex = 11;
            this.btn_Imprimir.Text = "Imprimir";
            this.btn_Imprimir.UseVisualStyleBackColor = true;
            this.btn_Imprimir.Click += new System.EventHandler(this.btn_Imprimir_Click);
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.Location = new System.Drawing.Point(531, 489);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(157, 48);
            this.btn_Alterar.TabIndex = 12;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // btn_Eliminar
            // 
            this.btn_Eliminar.Location = new System.Drawing.Point(720, 489);
            this.btn_Eliminar.Name = "btn_Eliminar";
            this.btn_Eliminar.Size = new System.Drawing.Size(147, 48);
            this.btn_Eliminar.TabIndex = 13;
            this.btn_Eliminar.Text = "Eliminar";
            this.btn_Eliminar.UseVisualStyleBackColor = true;
            this.btn_Eliminar.Click += new System.EventHandler(this.btn_Eliminar_Click);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(922, 489);
            this.btn_Sair.Name = "btn_Sair";
            this.btn_Sair.Size = new System.Drawing.Size(159, 52);
            this.btn_Sair.TabIndex = 14;
            this.btn_Sair.Text = "Sair";
            this.btn_Sair.UseVisualStyleBackColor = true;
            this.btn_Sair.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // printPreviewDialogLista
            // 
            this.printPreviewDialogLista.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialogLista.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialogLista.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialogLista.Document = this.printDocumentLista;
            this.printPreviewDialogLista.Enabled = true;
            this.printPreviewDialogLista.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialogLista.Icon")));
            this.printPreviewDialogLista.Name = "printPreviewDialogLista";
            this.printPreviewDialogLista.Visible = false;
            // 
            // printDocumentLista
            // 
            this.printDocumentLista.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocumentLista_PrintPage);
            // 
            // FormListaCarros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1179, 549);
            this.Controls.Add(this.btn_Imprimir);
            this.Controls.Add(this.btn_Alterar);
            this.Controls.Add(this.btn_Eliminar);
            this.Controls.Add(this.btn_Sair);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormListaCarros";
            this.Text = "Stand Aguiar, Lda.";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Adicionar_Dados;
        private System.Windows.Forms.Button btn_Limpar_Dados;
        private System.Windows.Forms.MaskedTextBox txt_KmsAtuais_Dados;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox txt_Matricula_Dados;
        private System.Windows.Forms.TextBox txt_Modelo_Dados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Marca_Dados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_Imprimir;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.Button btn_Eliminar;
        private System.Windows.Forms.Button btn_Sair;
        private System.Windows.Forms.ListBox ListaDekm;
        private System.Windows.Forms.ListBox ListaDeMatricula;
        private System.Windows.Forms.ListBox ListaDeModelo;
        private System.Windows.Forms.ListBox ListaDeMarca;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialogLista;
        private System.Drawing.Printing.PrintDocument printDocumentLista;
    }
}

